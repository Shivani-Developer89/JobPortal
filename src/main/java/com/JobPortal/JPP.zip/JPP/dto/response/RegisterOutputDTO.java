package com.JobPortal.JPP.dto.response;

import com.JobPortal.JPP.entity.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegisterOutputDTO {
    private Long id;
    private String name;

    private String email;


    private Role role;
    private String resumePath;

    private LocalDateTime resumeUploadedAt;
}
