package com.JobPortal.JPP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JppApplication.class, args);
	}

}
